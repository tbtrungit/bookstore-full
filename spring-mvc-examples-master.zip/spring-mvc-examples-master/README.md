Spring Boot, Java 8
===================

There is a new [spring_boot_form_builder](https://github.com/skprasadu/spring-mvc-examples/tree/master/spring_boot_form_builder) application refer [Wiki](https://github.com/skprasadu/spring-mvc-examples/wiki) for more details. It uses the latest [Spring Boot](http://projects.spring.io/spring-boot/) and [Spring Data](http://projects.spring.io/spring-data/).

Refer to this [blog](http://krishnasblog.com/2013/02/22/junit-testing-of-spring-mvc-application-introduction/) for initial draft details. But for latest changes refer [Wiki](https://github.com/skprasadu/spring-mvc-examples/wiki).
