package com.formbuilder.dto;

import lombok.Data;

@Data
public class NameValue {
	private String name;
	private String value;

}
