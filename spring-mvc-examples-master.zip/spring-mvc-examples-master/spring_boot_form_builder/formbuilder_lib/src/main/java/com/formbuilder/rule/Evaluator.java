package com.formbuilder.rule;

public interface Evaluator {
	public boolean eval();
}
