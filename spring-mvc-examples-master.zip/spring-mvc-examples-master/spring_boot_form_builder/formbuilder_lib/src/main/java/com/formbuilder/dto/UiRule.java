package com.formbuilder.dto;

import lombok.Data;

@Data
public class UiRule {
	
	private String id;
	private String uiRuleId;
	private String rule;
}
