package com.formbuilder.dto;

import lombok.Data;

@Data
public class ColumnDTO {
	
	private final String columnName;
	private final int columnType;
}
