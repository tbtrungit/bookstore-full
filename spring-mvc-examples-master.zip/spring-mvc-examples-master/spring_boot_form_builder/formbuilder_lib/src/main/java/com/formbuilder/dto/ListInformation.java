package com.formbuilder.dto;

import lombok.Data;
import lombok.Getter;

@Data
public class ListInformation {
	private final String id;
	
	private final String name;
}
