package com.formbuilder.drools;

import lombok.Data;

@Data
public class Message {

	public String type;
}
